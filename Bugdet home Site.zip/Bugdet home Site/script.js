function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('show');
}

// Get the modal
    var popup = document.getElementById("popup");

    // Get the button that opens the modal
    var openPopup = document.getElementById("openPopup");

    // Get the button that closes the modal
    var closePopup = document.getElementById("closePopup");

    // When the user clicks the button, open the modal 
    openPopup.onclick = function() {
        popup.style.display = "flex"; // Show the popup
    }

    // When the user clicks on the close button, close the modal
    closePopup.onclick = function() {
        popup.style.display = "none"; // Hide the popup
    }